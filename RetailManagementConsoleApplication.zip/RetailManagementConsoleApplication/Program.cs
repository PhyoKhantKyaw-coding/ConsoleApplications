﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
using RetailManagementConsoleApplication;

RetailService retailService = new RetailService();
retailService.Retail();
